public class Testen {   
    public static void main( String[] args){ 
        int a = Integer.parseInt(args[0]);

	System.out.println(a);
    }
}
